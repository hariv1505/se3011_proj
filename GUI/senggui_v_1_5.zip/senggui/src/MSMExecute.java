

public class MSMExecute implements Runnable {

	public void run() {
		
	}
}