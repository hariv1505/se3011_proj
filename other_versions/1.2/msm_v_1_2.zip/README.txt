SENG3011 - Group 13, "The Gs"

Congratulations on downloading the Momentum Strategy Module!

INSTALLATION
Extract the contents of this package into a folder.

Do NOT edit the contents of any files provided.

Windows OS
Execute the application simply by double-clicking msm_v_1_2.exe.
To execute the application using custom parameters, direct yourself into the directory using the command prompt and type "msm_v_1_2.exe".
These methods, without the use of flags will run the application using default parameters.

Linux OS
Execute the application by direct yourself into the directory using the command prompt and type "wine msm_v_1_2.exe".
This methods, without the use of flags will run the application using default parameters.

Further usage: msm_v_1_2 [options]
    -w, --window-size=window         Window Size for Moving Averages
    -t, --threshold=th               Threshold for moving averages
    -i, --input=inp                  Input file name (file must contain CSV data, and cannot be "newEntries.csv")
    -o, --output=ou                  Output file name (file will contain CSV data)
    -h, --help                       Displays Help

OS COMPATIBLITY
Windows XP, Vista, 7, 8, 8.1
Linux Ubuntu 12, 13

Thank you,
- The G's